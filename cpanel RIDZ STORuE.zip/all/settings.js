const fs = require('fs')
const chalk = require('chalk')

global.owner = "6285211724196"
global.ownerStore = "6285211724196"
global.namabot = "RIDZ STORE"
global.namaCreator = "RIDZ STORE"
global.namaStore = "RIDZ STORE"
global.autoJoin = true
global.antilink = false
global.themeemoji = '🪀'
global.versisc = '8.0.0'
global.namasc = 'V7 Campuran'
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.apitokendo = '-'
global.domain = 'domainisidisini' // Isi Domain Lu
global.apikey = 'ptlaisidisini' // Isi Apikey Plta Lu
global.capikey = 'ptlcisidisini' // Isi Apikey Pltc Lu
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.tekspushkonv3 = ""
global.tekspushkonv4 = ""
global.packname = ""
global.author = "Sticker By RIDZ STORE"
global.jumlah = "5"
global.youtube = "GAADA LOM BUAT"
global.grup = "https://chat.whatsapp.com/Bh7HCpnwckP8EWNosWrAzv"
global.telegram = "*Masih Proses Kak*"
global.instagram = "GAADA LOM BUAT"
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})